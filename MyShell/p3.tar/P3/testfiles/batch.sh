echo hello
cd notvaliddir
else cd notvaliddir
else cd P3
pwd
ls | cat